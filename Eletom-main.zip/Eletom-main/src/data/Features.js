export const Features = [
    {
        feature:"FO VALUE CALCULATION",
        type:[
            {
                pt:"yes",
                au:"No"
            }
        ]
    },
    {
        feature:"FO VALUE CALCULATION",
        type:[
            {
                pt:"yes",
                au:"No"
            }
        ]
    },
    {
        feature:"FO VALUE CALCULATION",
        type:[
            {
                pt:"yes",
                au:"No"
            }
        ]
    },
    {
        feature:"FO VALUE CALCULATION",
        type:[
            {
                pt:"yes",
                au:"No"
            }
        ]
    },
   
]