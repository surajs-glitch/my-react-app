import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { productsData } from "../data/Products";

import main from "../assets/productsMainDesktop.webp";
import redFrame from "../assets/framered.png";

import Header from "../common/Header";

const Products = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // const [isOpen, setIsOpen] = useState(false);
  // const dropdownRef = useRef();
  // Close dropdown when clicked outside
  // useEffect(() => {
  //   const handleClickOutside = (event) => {
  //     if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
  //       setIsOpen(false);
  //     }
  //   };
  //   document.addEventListener("mousedown", handleClickOutside);
  //   return () => document.removeEventListener("mousedown", handleClickOutside);
  // }, []);

  const [filteredProducts, setFilteredProducts] = useState(productsData);
  const [selectedType, setSelectedType] = useState("ALL");

  return (
    <div>
      {/*  */}
      <div className="w-full h-screen relative overflow-x-hidden">
        {/* <div className="absolute inset-0 bg-black/60"></div> */}
        <img className="h-full w-full object-cover" src={main} alt="" />
        <div className="inset-0 absolute text-center bg-black/40 flex flex-col lg:w-full justify-center">
          <h3 className="font-jost font-bold text-h1-mobile lg:text-[64px] text-white">
            Our Products
          </h3>
          <p className="font-roboto font-medium text-white text-h6-mobile lg:text-h4-desktop">
            We have Become a Trusted Partner for Research Institutions,
            Educational <br className="hidden lg:block" /> Facilities,
            Healthcare Providers, and Industrial Laboratories across the Globe.
          </p>
        </div>
      </div>
      {/* Products */}
      <div className="lg:w-[90%] m-auto lg:py-16 px-4 py-8 lg:px-0">
        {/* <h1 className="text-center lg:text-h2-desktop text-h2-mobile font-medium font-jost uppercase text-[#3A3A3A] border-b-[1px] border-black/30 pb-2">
          List of Products
        </h1> */}
        <div className="flex items-center justify-center gap-2 lg:gap-4 border-b-[1px] border-b-black/30 lg:pb-4 pb-2 ">
          <img className="lg:h-10 lg:w-10 w-8 h-8" src={redFrame} alt="" />
          <h1 className="text-red font-roboto font-bold lg:text-h2-desktop text-[#3A3A3A]  text-h3-mobile uppercase">
            LIST Of Products
          </h1>
        </div>
        <p className="text-center text-[#1D1D1D] font-jost font-light text-body-mobile lg:text-body-desktop capitalize mt-2">
          Explore our wide range of scientific instruments designed to power
          labs with accuracy and efficiency. <br /> Trusted across industries,
          our tools support research, diagnostics, and discovery
        </p>

        {/* Grid */}

        <div className="w-full grid grid-cols-1 lg:grid-cols-3 mt-4 lg:mt-6 gap-10 lg:gap-20 px-4 lg:px-0">
          {filteredProducts.map((product, index) => (
            <div key={index} className="py-4 px-2 ">
              <div className="relative  overflow-hidden group lg:py-2">
                <Link
                  to={
                    product.variants?.length === 1
                      ? `/products/${
                          product.slug
                        }/${product.variants[0].type.toLowerCase()}`
                      : `/products/${product.slug}`
                  }
                >
                  <img
                    src={product.image}
                    alt={`Product ${index}`}
                    className="lg:h-[320px] h-[250px] m-auto "
                  />
                </Link>
                {/* Hover Overlay */}
                {/* <div className="absolute inset-0 bg-black bg-opacity-35 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Link
                    to={`/products/${product.slug}`}
                    className="text-white lg:text-subtext-desktop bg-[#EE1B25] font-roboto font-bold px-4 py-2 rounded-[49px]"
                  >
                    Know more
                  </Link>
                </div> */}
                <div className="absolute inset-0 bg-black bg-opacity-35 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <Link
                    to={
                      product.variants?.length === 1
                        ? `/products/${
                            product.slug
                          }/${product.variants[0].type.toLowerCase()}`
                        : `/products/${product.slug}`
                    }
                    className="text-white lg:text-subtext-desktop bg-[#EE1B25] font-roboto font-bold px-4 py-2 rounded-[49px]"
                  >
                    Know more
                  </Link>
                </div>
              </div>

              <div className=" pb-2 mt-2 lg:mt-4">
                <h4 className="font-jost font-medium text-h5-mobile lg:text-h5-desktop">
                  {product.name}
                </h4>
                {/* <p className="border-[1px] border-[#DCDCDC] rounded-[104px] px-4 lg:py-0 font-jost text-body-mobile lg:text-body-desktop">
                  {product.type}
                </p> */}
              </div>
              {/* <ul>
                {
                  product.highlight.map((list,i) => (
                    <li className="text-[#999999] font-jost font-medium lg:text-subtext-desktop text-body-mobile" key={i}>{list}</li>
                  ))
                }
              </ul> */}
              <Link
                to={
                  product.variants?.length === 1
                    ? `/products/${
                        product.slug
                      }/${product.variants[0].type.toLowerCase()}`
                    : `/products/${product.slug}`
                }
              >
                <button className="w-full font-jost font-medium text-white py-2 bg-[#F11726]  lg:text-body-desktop mt-4">
                  Enquire
                </button>
              </Link>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Products;
