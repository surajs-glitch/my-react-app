import React, { Suspense, useRef, useState, useEffect } from "react";
import mainDesktop from "../assets/aboutMainDesktop.webp";
// import about from "../assets/aboutImage.png";
// const about = "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp/v1750253872/aboutImage_buusu1.png"
const about =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp/v1750670783/pexels-mike-van-schoonderwalt-1884800-5506026_naqldr.jpg";
import screw from "../assets/framered.png";

import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";

import certificate1 from "../assets/certificate1.png";
import certificate2 from "../assets/certificate2.png";
import certificate3 from "../assets/certificate3.png";
import certificate4 from "../assets/certificate4.png";

import certLarge1 from "../assets/certLarge1.png";
import certLarge2 from "../assets/certLarge2.png";
import certLarge3 from "../assets/certLarge3.png";
import certLarge4 from "../assets/certLarge4.png";

const enlargedImages = [certLarge1, certLarge2, certLarge3, certLarge4];

// import service1 from "../assets/service1.png";
// import service2 from "../assets/service2.png";
// import service3 from "../assets/service3.png";
// import service4 from "../assets/service4.png";
// import service5 from "../assets/service5.png";
// import service6 from "../assets/service6.png";
// import service7 from "../assets/service7.png";
// import service8 from "../assets/service8.png";
// import service9 from "../assets/service9.png";
// import serviceBlur1 from "../assets/serviceBlur1.png";
// import serviceBlur2 from "../assets/serviceBlur2.png";
// import serviceBlur3 from "../assets/serviceBlur3.png";
// import serviceBlur4 from "../assets/serviceBlur4.png";
// import serviceBlur5 from "../assets/serviceBlur5.png";
// import serviceBlur6 from "../assets/serviceBlur6.png";
// import serviceBlur7 from "../assets/serviceBlur7.png";
// import serviceBlur8 from "../assets/serviceBlur8.png";
// import serviceBlur9 from "../assets/serviceBlur9.png";
const service1 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253073/service1_tg3e0v.png";
const service2 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253073/service2_qbgps8.png";
const service3 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253075/service3_r4eu6m.png";
const service4 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253076/service4_ld9cby.png";
const service5 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253075/service5_ftuwyg.png";
const service6 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253072/service6_eigrog.png";
const service7 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253075/service7_f2gpof.png";
const service8 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253075/service8_gqxh8h.png";
const service9 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253077/service9_doftvr.png";

const serviceBlur1 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253076/serviceBlur1_mvg9ph.png";
const serviceBlur2 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253076/serviceBlur2_vsqas7.png";
const serviceBlur3 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253076/serviceBlur3_dgrthd.png";
const serviceBlur4 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253077/serviceBlur4_hzhiid.png";
const serviceBlur5 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253080/serviceBlur5_ur0ndj.png";
const serviceBlur6 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253077/serviceBlur6_z6lt1w.png";
const serviceBlur7 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253077/serviceBlur7_unlcpq.png";
const serviceBlur8 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253079/serviceBlur8_z0gi2i.png";
const serviceBlur9 =
  "https://res.cloudinary.com/dpwcgdzdi/image/upload/f_webp,q_auto/v1750253078/serviceBlur9_axxte6.png";

const services = [
  {
    image: service1,
    title: "Pharmaceutical",
    blur: serviceBlur1,
  },
  {
    image: service2,
    title: "FMCG Industry",
    blur: serviceBlur2,
  },
  {
    image: service3,
    title: "Academic & Research Institutions",
    blur: serviceBlur3,
  },
  {
    image: service4,
    title: "Testing Laboratories",
    blur: serviceBlur4,
  },
  {
    image: service5,
    title: "Hospitals & Clinical Labs",
    blur: serviceBlur5,
  },
  {
    image: service6,
    title: "Custom Industrial Projects",
    blur: serviceBlur6,
  },
  {
    image: service7,
    title: "Biotechnology",
    blur: serviceBlur7,
  },
  {
    image: service8,
    title: "Chemical Industry",
    blur: serviceBlur8,
  },
  {
    image: service9,
    title: "Cosmetics Industry",
    blur: serviceBlur9,
  },
];

const FAQs = React.lazy(() => import("../components/FAQs"));
const Contact = React.lazy(() => import("../components/Question"));

const About = () => {
  const prevRef = useRef(null);
  const nextRef = useRef(null);
  const [swiperInstance, setSwiperInstance] = useState(null);

  useEffect(() => {
    if (!swiperInstance) return;

    swiperInstance.params.navigation.prevEl = prevRef.current;
    swiperInstance.params.navigation.nextEl = nextRef.current;

    swiperInstance.navigation.init();
    swiperInstance.navigation.update();
  }, [swiperInstance]);

  const [showModal, setShowModal] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const openModal = () => {
    setCurrentIndex(0);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const goNext = () => {
    setCurrentIndex((prev) => (prev + 1) % enlargedImages.length);
  };

  const goPrev = () => {
    setCurrentIndex((prev) =>
      prev === 0 ? enlargedImages.length - 1 : prev - 1
    );
  };
  return (
    <div className="w-full">
      {/* Main */}
      <div className="w-full h-screen relative">
        <img
          className="h-full w-full object-cover relative"
          src={mainDesktop}
          alt=""
        />
        <div className="absolute inset-0 text-center bg-black/40 flex flex-col lg:w-full justify-center">
          <h1 className="font-jost font-bold text-white text-h1-mobile lg:text-[64px]">
            About Us
          </h1>
          <p className="font-roboto text-white font-medium text-h6-mobile lg:text-h4-desktop">
            We Manufacture Premium Range of Products in Our Segment,{" "}
            <br className="hidden lg:block" /> with Competitive Prices and the
            Best Dealer Network.
          </p>
        </div>
      </div>
      {/* Content 1 */}
      <div className="px-4 lg:px-20 py-8 lg:py-16 h-fit flex flex-col gap-6 lg:gap-0 lg:flex-row justify-between">
        <div className="lg:w-[40%] hidden">
          <img
            className="rounded-[25px] h-[300px] lg:h-[500px] w-full object-cover"
            src={about}
            alt=""
          />
        </div>
        <div className="lg:w-[100%] space-y-2">
          <div className="flex w-full justify-center items-center gap-2 border-b-[1px] border-black/30 lg:pb-4 pb-2">
            <img className="lg:w-10  w-8" src={screw} alt="" />
            <p className="font-roboto font-bold text-h2-mobile lg:text-h2-desktop text-[#3A3A3A] uppercase">
              Know about us
            </p>
          </div>

          <p className="text-black font-jost text-body-mobile lg:text-body-desktop text-justify">
            Our Laboratory Instruments are Engineered for Precision, Durability,
            and Ease of Use. Built with High-Grade Materials and Cutting-Edge
            Technology, Each Unit Undergoes Rigorous Quality Checks to Meet
            Global Standards like ISO, CE, EN, and IEC. Designed to Support
            Pharmaceutical, FMCG, Academic, and Clinical Applications, Our
            Products Offer Excellent Performance, Energy Efficiency, and
            Long-Term Reliability. Custom Configurations and Remote Servicing
            Options are also Available to Meet Specific Project Needs.
          </p>
          <p className="text-black font-jost text-body-mobile lg:text-body-desktop text-justify">
            We Specialize in A Wide Range of Laboratory Instruments, Including
            List Key Products, E.G., AUTOCLAVE, BOD INCUBATORS, CHILLERS, DUAL
            CHAMBERS, FREEZERS, HOT AIR OVENS, INCUBATORS, MUFFLE FURNACE,
            REFRIGERATORS, STABILITY CHAMBER, VACUUM OVEN, WATER BATH, Tailored
            to Meet Diverse Scientific Needs. Our Commitment to Innovation
            Ensures That We Continually Incorporate the Latest Technologies and
            Industry Trends to Support Evolving Research Demands.
          </p>
          <p className="text-black font-jost text-body-mobile lg:text-body-desktop text-justify">
            At ELETOM79, Quality and Customer Satisfaction Are at The Core of
            Everything We Do. We Pride Ourselves on Building Long-Term
            Relationships Through Exceptional After-Sales Support, Training, And
            Maintenance Services.
          </p>
          <p className="text-black font-jost text-body-mobile lg:text-body-desktop text-justify">
            Join Us in Shaping the Future of Science with Instruments Designed
            for Precision, Reliability, And Excellence.
          </p>

          <div className="flex w-full justify-center items-center gap-2 border-b-[1px] border-black/30 lg:pb-4 pb-2 pt-4 lg:pt-8">
            <img className="lg:w-8 w-8" src={screw} alt="" />
            <p className="font-roboto font-bold text-h3-mobile lg:text-h2-desktop text-[#3A3A3A] uppercase ">
              Our Certifications
            </p>
          </div>
          <div className="hidden relative group w-full flex justify-center gap-4 lg:gap-6">
            {/* Certificates Row */}
            <div className="flex justify-center gap-4 lg:gap-6 w-full z-10 py-2">
              <img
                className="lg:h-[60px] h-[50px]"
                src={certificate1}
                alt="Certificate 1"
              />
              <img
                className="lg:h-[60px] h-[50px]"
                src={certificate2}
                alt="Certificate 2"
              />
              <img
                className="lg:h-[60px] h-[50px]"
                src={certificate3}
                alt="Certificate 3"
              />
              <img
                className="lg:h-[60px] h-[50px]"
                src={certificate4}
                alt="Certificate 4"
              />
            </div>

            {/* Hover Overlay */}
            <div
              className="absolute inset-0 bg-black/20 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center z-20 rounded-md cursor-pointer"
              onClick={openModal}
            >
              <p className="text-[#EE1D23] font-jost lg:text-h5-desktop font-semibold">
                See Certifications
              </p>
            </div>

            {/* Modal with Slider */}
            {showModal && (
              <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center px-4">
                <div className="bg-white rounded-lg p-6 relative max-w-[90vw] w-full flex flex-col items-center">
                  {/* Close Button */}
                  <button
                    className="absolute top-3 right-4 text-black text-2xl font-bold"
                    onClick={closeModal}
                  >
                    ×
                  </button>

                  {/* Image Carousel */}
                  <div className="flex items-center gap-4 w-full justify-center">
                    <button
                      onClick={goPrev}
                      className="text-2xl font-bold text-[#EE1D23] px-4"
                    >
                      &#8592;
                    </button>

                    <img
                      src={enlargedImages[currentIndex]}
                      alt={`Certificate ${currentIndex + 1}`}
                      className="h-[300px] lg:h-[600px] max-w-full object-contain transition-all duration-300"
                    />

                    <button
                      onClick={goNext}
                      className="text-2xl font-bold text-[#EE1D23] px-4"
                    >
                      &#8594;
                    </button>
                  </div>

                  {/* Index Indicator */}
                  <p className="mt-4 text-sm text-gray-600 font-jost">
                    {currentIndex + 1} / {enlargedImages.length}
                  </p>
                </div>
              </div>
            )}
          </div>
          <div className="w-full grid grid-cols-1 lg:grid-cols-2 gap-4 lg:gap-16 items-center pt-6 lg:pt-12">
            {enlargedImages.map((item, index) => (
              <div
                key={index}
                className={` flex ${
                  index % 2 === 0 ? "justify-end" : "justify-start"
                }`}
              >
                <img
                  className="lg:h-[400px] border-[1px] p-2 border-black"
                  src={item}
                  alt={`Image ${index + 1}`}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
      {/* Grid */}
      <div className="lg:px-20 px-4">
        <div className="flex w-full justify-center items-center gap-2 border-b-[1px] border-black/30 lg:pb-4 pb-2">
          <img className="w-8 lg:w-10" src={screw} alt="" />
          <p className="font-roboto font-bold text-h3-mobile lg:text-h2-desktop text-[#3A3A3A] uppercase">
            Industries We Serve
          </p>
        </div>
        <p className="text-[#686C72] text-center font-jost text-h6-mobile lg:text-h6-desktop mt-2">
          Crafting Innovative Lab Instruments Trusted Globally by Biotech,
          Pharmaceutical, and Research Leaders.
        </p>

        <>
          {/* Desktop Grid (hide on mobile) */}
          <div className="hidden lg:grid lg:grid-cols-3 lg:gap-10 mt-4 lg:mt-12">
            {services.map((service, index) => (
              <div key={index} className="relative">
                <img
                  className="rounded-[20px] w-full"
                  src={service.image}
                  alt=""
                />
                <img
                  className="absolute w-full bottom-0 rounded-b-[20px]"
                  src={service.blur}
                  alt=""
                />
                <p className="absolute left-4 bottom-4 text-white font-jost font-semibold lg:text-h5-desktop z-20">
                  {service.title}
                </p>
              </div>
            ))}
          </div>

          {/* Mobile Swiper (show on mobile) */}
          <div className="lg:hidden mt-4 relative">
            <Swiper
              modules={[Navigation]}
              onSwiper={setSwiperInstance}
              // spaceBetween={20}
              loop={false}
              breakpoints={{
                320: {
                  slidesPerView: 1,
                  slidesPerGroup: 1,
                  spaceBetween: "20",
                },
                1024: {
                  slidesPerView: 3,
                  slidesPerGroup: 3,
                  spaceBetween: "40",
                },
              }}
            >
              {services.map((service, index) => (
                <SwiperSlide key={index}>
                  <div className="relative">
                    <img
                      className="rounded-[20px]  w-full object-cover"
                      src={service.image}
                      alt={service.title}
                    />
                    <img
                      className="absolute w-full bottom-0 rounded-b-[20px]"
                      src={service.blur}
                      alt=""
                    />
                    <p className="absolute left-4 bottom-4 text-white font-jost font-semibold text-h3-mobile z-20">
                      {service.title}
                    </p>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>

            {/* Custom navigation buttons centered */}
            <button
              ref={prevRef}
              className="left-2 absolute z-10 top-[45%]  bg-[#EEEEEE] lg:h-12 lg:w-12 rounded-full lg:flex justify-center items-center p-4"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="2"
                stroke="#1e1e1e"
                class="size-5"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18"
                />
              </svg>
            </button>
            <button
              ref={nextRef}
              className="right-2 absolute z-10 top-[45%]  bg-[#EEEEEE] lg:h-12 lg:w-12 rounded-full lg:flex justify-center items-center p-4"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="2"
                stroke="#1e1e1e"
                class="size-5"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </button>
          </div>
        </>
      </div>
      <Suspense>
        <FAQs />
        {/* <Contact /> */}
      </Suspense>
    </div>
  );
};

export default About;
